from __future__ import annotations

from dataclasses import asdict, dataclass
import json
from pathlib import Path
import re

from pdf_parser import CodePdfParser, PdfParseError, TextExtractionProvider
from question_splitter import RuleQuestionSplitter
from schemas import Question, UploadedPaper


QUESTION_START_MARKER = "###QUESTION###"
QUESTION_END_MARKER = "###END###"
DEFAULT_NL_TOKEN = " [NL] "
FORMULA_GLYPH_MAP = {
    "\uf02b": ".",
    "\uf02d": "-",
    "\uf03c": "<",
    "\uf03e": ">",
    "\uf044": "Δ",
    "\uf04b": "…",
    "\uf057": "Θ",
    "\uf063": "χ",
    "\uf064": "δ",
    "\uf065": "ε",
    "\uf06c": "λ",
    "\uf06d": "μ",
    "\uf06f": "∘",
    "\uf070": "π",
    "\uf071": "O",
    "\uf073": "σ",
    "\uf022": "∀",
    "\uf024": "∃",
    "\uf0a3": "α",
    "\uf0a5": "∞",
    "\uf0a0": "-",
    "\uf0a2": "'",
    "\uf0ab": "∨",
    "\uf0ac": "←",
    "\uf0ae": "→",
    "\uf0b3": "≥",
    "\uf0b4": "×",
    "\uf0b9": "⊆",
    "\uf0c6": "d",
    "\uf0c7": "∩",
    "\uf0c8": "∪",
    "\uf0cd": "⊆",
    "\uf0ce": "∈",
    "\uf0cf": "π",
    "\uf0d7": "·",
    "\uf0d8": "¬",
    "\uf0d9": "∧",
    "\uf0da": "∨",
    "\uf0de": "⊨",
    "\uf0e5": "Σ",
    "\uf0ef": "{",
    "\uf0fc": "√",
    "\uf061": "α",
    "\uf077": "ω",
}
GENERIC_PARENT_NAMES = {
    "data",
    "datasets",
    "history_bank",
    "history_bank_verify_tmp",
    "history_bank_verify_tmp2",
    "st",
}
PAPER_SIDE_NAMES = {"a", "b"}


@dataclass(slots=True)
class CozeExportRecord:
    source_pdf: str
    output_txt: str | None
    paper_label: str
    subject: str
    page_count: int
    question_count: int
    status: str
    error: str = ""

    def to_dict(self) -> dict[str, str | int]:
        return asdict(self)


def infer_subject(pdf_path: Path) -> str:
    from_filename = _infer_subject_from_filename(pdf_path.stem)
    if from_filename:
        return from_filename

    for parent in pdf_path.parents:
        name = parent.name.strip()
        if not name:
            continue
        if name.lower() in GENERIC_PARENT_NAMES:
            continue
        if _looks_like_year_term(name):
            continue
        return name
    return "unknown"


def export_pdf_to_coze_txt(
    pdf_path: Path,
    output_path: Path,
    *,
    extraction_provider: TextExtractionProvider | None = None,
    split_provider: RuleQuestionSplitter | None = None,
    subject_override: str | None = None,
    paper_id: str = "H1",
    nl_token: str = DEFAULT_NL_TOKEN,
) -> CozeExportRecord:
    extraction_provider = extraction_provider or CodePdfParser()
    split_provider = split_provider or RuleQuestionSplitter()

    subject = (subject_override or infer_subject(pdf_path)).strip() or "unknown"
    paper_label = pdf_path.stem

    try:
        text_content, page_count = extraction_provider.extract(pdf_path)
        paper = UploadedPaper(
            paper_id=paper_id,
            filename=pdf_path.name,
            subject=subject,
            temp_path=str(pdf_path),
            text_content=text_content,
            page_count=page_count,
        )
        questions = split_provider.split(text_content, paper_id)
    except PdfParseError as exc:
        return CozeExportRecord(
            source_pdf=str(pdf_path),
            output_txt=None,
            paper_label=paper_label,
            subject=subject,
            page_count=0,
            question_count=0,
            status="failed",
            error=str(exc),
        )

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(
        build_coze_document(paper=paper, questions=questions, source_pdf=pdf_path, nl_token=nl_token),
        encoding="utf-8",
    )

    return CozeExportRecord(
        source_pdf=str(pdf_path),
        output_txt=str(output_path),
        paper_label=paper_label,
        subject=subject,
        page_count=paper.page_count,
        question_count=len(questions),
        status="ok",
    )


def export_pdf_tree_to_coze_txt(
    input_root: Path,
    output_root: Path,
    *,
    extraction_provider: TextExtractionProvider | None = None,
    split_provider: RuleQuestionSplitter | None = None,
    subject_override: str | None = None,
    nl_token: str = DEFAULT_NL_TOKEN,
) -> list[CozeExportRecord]:
    records: list[CozeExportRecord] = []
    pdf_files = sorted(input_root.rglob("*.pdf"), key=lambda current: str(current).lower())

    for index, pdf_path in enumerate(pdf_files, start=1):
        relative_path = pdf_path.relative_to(input_root)
        output_path = (output_root / relative_path).with_suffix(".coze.txt")
        records.append(
            export_pdf_to_coze_txt(
                pdf_path,
                output_path,
                extraction_provider=extraction_provider,
                split_provider=split_provider,
                subject_override=subject_override,
                paper_id=f"H{index}",
                nl_token=nl_token,
            )
        )

    return records


def build_coze_document(
    *,
    paper: UploadedPaper,
    questions: list[Question],
    source_pdf: Path,
    nl_token: str = DEFAULT_NL_TOKEN,
) -> str:
    paper_label = source_pdf.stem
    subject = paper.subject or "unknown"

    if not questions:
        return (
            _build_question_line(
                paper_id=paper.paper_id,
                paper_label=paper_label,
                subject=subject,
                question_no="1",
                order=1,
                content=paper.text_content,
                nl_token=nl_token,
            )
            + "\n"
        )

    return (
        "\n".join(
            _build_question_line(
                paper_id=paper.paper_id,
                paper_label=paper_label,
                subject=subject,
                question_no=question.question_no,
                order=question.order,
                content=question.content,
                nl_token=nl_token,
            )
            for question in questions
        ).strip()
        + "\n"
    )


def write_manifest(records: list[CozeExportRecord], manifest_path: Path) -> None:
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "total": len(records),
        "succeeded": sum(1 for record in records if record.status == "ok"),
        "failed": sum(1 for record in records if record.status != "ok"),
        "items": [record.to_dict() for record in records],
    }
    manifest_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def sanitize_block(text: str) -> str:
    normalized = text.replace("\r\n", "\n").replace("\r", "\n").replace("\u3000", " ")
    normalized = normalize_formula_glyphs(normalized)
    normalized = re.sub(r"[ \t]+", " ", normalized)
    normalized = re.sub(r"\n{3,}", "\n\n", normalized)
    lines = [line.strip() for line in normalized.split("\n")]
    return "\n".join(line for line in lines if line).strip()


def normalize_formula_glyphs(text: str) -> str:
    normalized = text
    for source, target in FORMULA_GLYPH_MAP.items():
        normalized = normalized.replace(source, target)
    normalized = re.sub(r"\ufffd+", " ", normalized)
    normalized = re.sub(r"[\uf0ec\uf0ed\uf0ee]+", "{", normalized)
    normalized = re.sub(r"[\uf0f6\uf0f7\uf0f8]+", "}", normalized)
    normalized = re.sub(r"[\uf0e6\uf0e7\uf0e8]+", "[", normalized)
    normalized = re.sub(r"[\uf0fa\uf0fb]+", "]", normalized)
    normalized = re.sub(r"[\uf0ea]+", "[", normalized)
    normalized = re.sub(r"[\uf0eb]+", "]", normalized)
    normalized = re.sub(r"([\(\uff08])\s*([∀∃])\s*([A-Za-z])", r"\1\2\3", normalized)
    normalized = re.sub(r"([¬∀∃])\s+([A-Za-z])", r"\1\2", normalized)
    normalized = re.sub(r"\s*([∨∧→↔⊨×∩∪⊆←])\s*", r" \1 ", normalized)
    normalized = re.sub(r"\s*([<>≤≥∈∘·])\s*", r" \1 ", normalized)
    normalized = re.sub(r"\{\s+", "{", normalized)
    normalized = re.sub(r"\s+\}", "}", normalized)
    normalized = re.sub(r"\[\s+", "[", normalized)
    normalized = re.sub(r"\s+\]", "]", normalized)
    normalized = re.sub(r" {2,}", " ", normalized)
    return normalized


def _build_question_line(
    *,
    paper_id: str,
    paper_label: str,
    subject: str,
    question_no: str,
    order: int,
    content: str,
    nl_token: str,
) -> str:
    flattened_content = sanitize_block(content).replace("\n", nl_token)
    return (
        f"{QUESTION_START_MARKER} "
        f"paper_id: {paper_id} | "
        f"paper_label: {paper_label} | "
        f"subject: {subject} | "
        f"question_no: {question_no} | "
        f"order: {order} | "
        f"content: {flattened_content} "
        f"{QUESTION_END_MARKER}"
    )


def _infer_subject_from_filename(stem: str) -> str:
    parts = [part.strip() for part in stem.split("+") if part.strip()]
    if len(parts) >= 3:
        candidate = parts[2]
        if candidate.lower() not in PAPER_SIDE_NAMES and not _looks_like_year_term(candidate):
            return candidate
    return ""


def _looks_like_year_term(value: str) -> bool:
    compact = re.sub(r"\s+", "", value)
    return bool(re.fullmatch(r"[（(]?\d{2,4}-\d{2,4}-\d[）)]?", compact))
