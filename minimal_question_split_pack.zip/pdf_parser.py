from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path


class PdfParseError(Exception):
    """Raised when PDF text extraction fails in a user-facing way."""


class TextExtractionProvider(ABC):
    provider_name = "unknown"
    provider_label = "text extractor"

    @abstractmethod
    def extract(self, pdf_path: Path) -> tuple[str, int]:
        """Extract text and page count from a PDF path."""


class CodePdfParser(TextExtractionProvider):
    provider_name = "code_pdf_parser"
    provider_label = "pdfplumber extractor"

    def extract(self, pdf_path: Path) -> tuple[str, int]:
        return _extract_text_with_pdfplumber(pdf_path)


def extract_text_from_pdf(pdf_path: Path) -> tuple[str, int]:
    return CodePdfParser().extract(pdf_path)


def _extract_text_with_pdfplumber(pdf_path: Path) -> tuple[str, int]:
    if not pdf_path.exists():
        raise PdfParseError(f"PDF file not found: {pdf_path}")

    try:
        import pdfplumber
    except ImportError as exc:
        raise PdfParseError(
            "pdfplumber is not installed. Run `pip install -r requirements.txt` first."
        ) from exc

    try:
        page_texts: list[str] = []
        with pdfplumber.open(str(pdf_path)) as pdf:
            page_count = len(pdf.pages)
            for page in pdf.pages:
                text = page.extract_text() or ""
                if text.strip():
                    page_texts.append(text.strip())
    except Exception as exc:
        raise PdfParseError(f"Failed to parse {pdf_path.name}: {exc}") from exc

    if not page_texts:
        raise PdfParseError(
            f"No usable text was extracted from {pdf_path.name}. "
            "This tool currently supports text-based PDFs, not scanned image PDFs."
        )

    return "\n\n".join(page_texts), page_count
