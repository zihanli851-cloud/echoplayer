@echo off
python "%~dp0run_export.py" %*
