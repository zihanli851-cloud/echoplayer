from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class UploadedPaper:
    paper_id: str
    filename: str
    subject: str
    temp_path: str
    text_content: str = ""
    page_count: int = 0


@dataclass(slots=True)
class Question:
    question_id: str
    paper_id: str
    question_no: str
    order: int
    content: str
    raw_block: str = ""
    paper_label: str | None = None
