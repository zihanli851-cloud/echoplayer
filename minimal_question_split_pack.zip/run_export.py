from __future__ import annotations

import argparse
from pathlib import Path

from coze_export import DEFAULT_NL_TOKEN, export_pdf_to_coze_txt, export_pdf_tree_to_coze_txt, write_manifest


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Export exam PDFs into Coze-friendly one-question-per-line text files.",
    )
    parser.add_argument("input_path", help="Source PDF file or directory containing PDFs.")
    parser.add_argument("--output-dir", required=True, help="Directory to receive generated .coze.txt files.")
    parser.add_argument("--subject", default="", help="Optional fixed subject override for all exported papers.")
    parser.add_argument(
        "--nl-token",
        default=DEFAULT_NL_TOKEN,
        help="Token used to replace original line breaks inside one question. Default: ' [NL] '.",
    )
    parser.add_argument(
        "--manifest-name",
        default="manifest.json",
        help="Manifest filename written under the output directory.",
    )
    return parser


def main() -> int:
    args = build_parser().parse_args()
    input_path = Path(args.input_path).resolve()
    output_dir = Path(args.output_dir).resolve()
    subject_override = args.subject.strip() or None

    if not input_path.exists():
        print(f"Input path does not exist: {input_path}")
        return 1

    if input_path.is_file():
        output_file = output_dir / f"{input_path.stem}.coze.txt"
        records = [
            export_pdf_to_coze_txt(
                input_path,
                output_file,
                subject_override=subject_override,
                paper_id="H1",
                nl_token=args.nl_token,
            )
        ]
    else:
        records = export_pdf_tree_to_coze_txt(
            input_path,
            output_dir,
            subject_override=subject_override,
            nl_token=args.nl_token,
        )

    manifest_path = output_dir / args.manifest_name
    write_manifest(records, manifest_path)

    success_count = sum(1 for record in records if record.status == "ok")
    fail_count = len(records) - success_count

    print(f"Input: {input_path}")
    print(f"Output: {output_dir}")
    print(f"Generated: {success_count}")
    print(f"Failed: {fail_count}")
    print(f"Manifest: {manifest_path}")

    for record in records:
        if record.status != "ok":
            print(f"[FAILED] {record.source_pdf}: {record.error}")

    return 0 if fail_count == 0 else 2


if __name__ == "__main__":
    raise SystemExit(main())
