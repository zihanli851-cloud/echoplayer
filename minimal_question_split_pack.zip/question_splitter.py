from __future__ import annotations

import re

from schemas import Question


CHINESE_NUMERAL_PATTERN = re.compile(
    r"^(?P<label>[一二三四五六七八九十]+)[、,，.．:：)）]\s*(?P<body>.*)$"
)
CHINESE_SECTION_PATTERN = re.compile(
    r"^(?P<label>[一二三四五六七八九十]+)(?:[、,，.．:：)）]|\s+)\s*(?P<body>.*)$"
)
ARABIC_PATTERN = re.compile(
    r"^(?P<label>[1-9]\d*)(?:[、]|[.．](?!\d)|[)）](?!\d))\s*(?P<body>.*)$"
)
PAGE_NUMBER_PATTERN = re.compile(r"^\d{1,3}$")
OPTION_LABEL_PATTERN = re.compile(r"(?:^|\s)(?:\[(?P<bracket>[A-D])\]|(?P<plain>[A-D])[.、．)])")
OPTION_TAIL_PATTERN = re.compile(r"(?:^|\s)(?:\[(?:A|B|C|D)\]|(?:A|B|C|D)[.、．)])\s*$")
SHORT_NUMERIC_FRAGMENT_PATTERN = re.compile(
    r"^[\d,\s，.;:：…]+(?:\s*(?:\[(?:A|B|C|D)\]|(?:A|B|C|D)[.、．)]))?$"
)

FRAGMENT_ENDINGS = (
    "为",
    "是",
    "有",
    "和",
    "或",
    "及",
    "在",
    "由",
    "向",
    "与",
    "其",
    "该",
    "令",
    "若",
    "则",
    "按",
    "把",
    "将",
    "如下",
    "序列是",
)

SECTION_HEADING_KEYWORDS = (
    "选择题",
    "单项选择题",
    "多项选择题",
    "填空题",
    "判断题",
    "问答题",
    "简答题",
    "论述题",
    "名词解释",
    "编程题",
    "应用题",
    "计算题",
    "证明题",
    "分析题",
    "案例题",
    "案例分析题",
    "综合题",
    "阅读题",
    "翻译题",
    "实验题",
    "操作题",
)

PREAMBLE_TRIGGER_KEYWORDS = (
    "以下各项由命题教师填写",
    "以下各项由学生填写",
    "课程名称",
    "命题教师",
    "适用对象",
    "使用试题的任课教师姓名",
    "试题说明",
    "试卷说明",
    "考试说明",
    "考生注意事项",
    "考试时间",
    "考试类型",
    "考试用品",
    "任课教师",
    "学生姓名",
    "学号",
)


class RuleQuestionSplitter:
    provider_name = "rule_question_splitter"
    provider_label = "rule-based question splitter"

    def split(self, text: str, paper_id: str) -> list[Question]:
        return _split_questions_impl(text, paper_id)


def split_questions(text: str, paper_id: str) -> list[Question]:
    return RuleQuestionSplitter().split(text, paper_id)


def normalize_question_text(text: str) -> str:
    normalized = text.replace("\r\n", "\n").replace("\r", "\n").replace("\u3000", " ")
    normalized = re.sub(r"[ \t]+", " ", normalized)
    normalized = re.sub(
        r"(?<![=<>+\-*/,:：，,（({<]) +([一二三四五六七八九十]+[、,，.．:：)）])",
        r"\n\1",
        normalized,
    )
    normalized = re.sub(
        r"(?<![=<>+\-*/,:：，,（({<]) +((?:[1-9]\d*[、]|(?:[1-9]\d*[.．](?!\d))|(?:[1-9]\d*[)）](?!\d))))",
        r"\n\1",
        normalized,
    )
    normalized = re.sub(r" +([（(]\d+[)）])", r"\n\1", normalized)
    return normalized.strip()


def split_normalized_lines(text: str) -> list[str]:
    return [
        line.strip()
        for line in text.split("\n")
        if line.strip() and not PAGE_NUMBER_PATTERN.fullmatch(line.strip())
    ]


def match_question_marker(line: str) -> tuple[str, str] | None:
    for pattern in (CHINESE_NUMERAL_PATTERN, ARABIC_PATTERN):
        match = pattern.match(line)
        if match:
            return match.group("label"), match.group("body").strip()
    return None


def is_section_heading(line: str) -> bool:
    for pattern in (CHINESE_SECTION_PATTERN, ARABIC_PATTERN):
        match = pattern.match(line)
        if not match:
            continue
        body = match.group("body").strip()
        if any(keyword in body for keyword in SECTION_HEADING_KEYWORDS):
            return True
    return False


def strip_preamble_lines(lines: list[str]) -> list[str]:
    if not lines:
        return lines

    in_preamble = False
    for index, line in enumerate(lines):
        if any(keyword in line for keyword in PREAMBLE_TRIGGER_KEYWORDS):
            in_preamble = True
            continue
        if is_section_heading(line):
            return lines[index:]
        marker = match_question_marker(line)
        if not marker:
            continue
        label, _ = marker
        if in_preamble and label.isdigit():
            continue
        return lines[index:]
    return lines


def _split_questions_impl(text: str, paper_id: str) -> list[Question]:
    normalized_text = normalize_question_text(text)
    if not normalized_text:
        return []

    lines = strip_preamble_lines(split_normalized_lines(normalized_text))
    questions: list[Question] = []
    current_label: str | None = None
    current_lines: list[str] = []

    def flush_current() -> None:
        if current_label is None:
            return
        content = "\n".join(current_lines).strip()
        if not content:
            return
        order = len(questions) + 1
        questions.append(
            Question(
                question_id=f"{paper_id}-{order}",
                paper_id=paper_id,
                question_no=current_label,
                order=order,
                content=content,
                raw_block=content,
            )
        )

    for line in lines:
        if is_section_heading(line):
            flush_current()
            current_label = None
            current_lines = []
            continue

        marker = match_question_marker(line)
        if marker:
            flush_current()
            current_label, body = marker
            current_lines = [body] if body else []
            continue

        if current_label is None:
            current_label = "1"
            current_lines = [line]
        else:
            current_lines.append(line)

    flush_current()

    if questions:
        return _coalesce_fragmented_questions(questions, paper_id)

    return [
        Question(
            question_id=f"{paper_id}-1",
            paper_id=paper_id,
            question_no="1",
            order=1,
            content=normalized_text,
            raw_block=normalized_text,
        )
    ]


def _coalesce_fragmented_questions(questions: list[Question], paper_id: str) -> list[Question]:
    merged: list[Question] = []
    index = 0

    while index < len(questions):
        current = questions[index]
        while index + 1 < len(questions) and _should_merge_with_next_question(current, questions[index + 1]):
            next_question = questions[index + 1]
            merged_content = "\n".join(
                part.strip()
                for part in (current.content, next_question.content)
                if part.strip()
            )
            current = Question(
                question_id=current.question_id,
                paper_id=current.paper_id,
                question_no=current.question_no,
                order=current.order,
                content=merged_content,
                raw_block=merged_content,
                paper_label=current.paper_label,
            )
            index += 1
        merged.append(current)
        index += 1

    normalized_questions: list[Question] = []
    for order, question in enumerate(merged, start=1):
        normalized_questions.append(
            Question(
                question_id=f"{paper_id}-{order}",
                paper_id=question.paper_id,
                question_no=question.question_no,
                order=order,
                content=question.content,
                raw_block=question.content,
                paper_label=question.paper_label,
            )
        )
    return normalized_questions


def _should_merge_with_next_question(current: Question, next_question: Question) -> bool:
    current_text = current.content.strip()
    next_text = next_question.content.strip()

    if not current_text or not next_text:
        return False
    if current.question_no == next_question.question_no:
        return True
    if _has_incomplete_option_block(current_text) and _looks_like_option_fragment(next_text):
        return True
    if _looks_like_question_fragment(current_text):
        return True
    return False


def _has_incomplete_option_block(text: str) -> bool:
    labels = {match.group("bracket") or match.group("plain") for match in OPTION_LABEL_PATTERN.finditer(text)}
    return bool(labels) and labels != {"A", "B", "C", "D"}


def _looks_like_option_fragment(text: str) -> bool:
    compact = text.replace("\n", " ").strip()
    if not compact:
        return False
    if SHORT_NUMERIC_FRAGMENT_PATTERN.fullmatch(compact):
        return True
    if OPTION_TAIL_PATTERN.search(compact):
        return True
    if len(compact) <= 24 and any(token in compact for token in ("[A]", "[B]", "[C]", "[D]")):
        return True
    return False


def _looks_like_question_fragment(text: str) -> bool:
    compact = text.replace("\n", " ").strip()
    if not compact:
        return False
    if _looks_like_option_fragment(compact):
        return True
    if len(compact) <= 6 and "题" not in compact:
        return True
    if OPTION_TAIL_PATTERN.search(compact):
        return True
    if any(compact.endswith(ending) for ending in FRAGMENT_ENDINGS):
        return True
    return False
