# 最小可运行切题包

这个目录是一个独立版 PDF 试卷预处理工具，功能只有 3 个：

1. 从 PDF 提取文本
2. 按题号规则切题
3. 导出成适合 Coze 知识库上传的 `.coze.txt`

它不依赖主项目的 `app/` 目录，也不依赖 Coze API、数据库或 Web 服务，单独发给别人即可运行。

## 目录说明

- `run_export.py`：命令行入口
- `pdf_parser.py`：PDF 文本提取
- `question_splitter.py`：规则切题
- `coze_export.py`：导出 Coze 文本、公式符号清洗
- `schemas.py`：最小数据结构
- `requirements.txt`：最小依赖

## 安装

```powershell
cd deliverables\minimal_question_split_pack
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

如果你本机已经有 Python 环境，也可以直接：

```powershell
pip install -r requirements.txt
```

## 运行方式

### 1. 处理单个 PDF

```powershell
python run_export.py "D:\path\to\paper.pdf" --output-dir "D:\path\to\output"
```

### 2. 批量处理整个目录

```powershell
python run_export.py "D:\path\to\pdf_folder" --output-dir "D:\path\to\output"
```

### 3. 强制指定科目

```powershell
python run_export.py "D:\path\to\pdf_folder" --output-dir "D:\path\to\output" --subject "离散数学"
```

## 输出结果

每个 PDF 会生成一个对应的 `.coze.txt` 文件，内容格式类似：

```text
###QUESTION### paper_id: H1 | paper_label: 示例试卷 | subject: 离散数学 | question_no: 1 | order: 1 | content: 命题内容 [NL] A. 选项1 [NL] B. 选项2 ###END###
```

说明：

- 每一行对应一道题，适合在 Coze 里按换行做自定义切分
- `question_no` 是题号
- `paper_label` 是原 PDF 文件名
- `subject` 会优先从文件名推断，推断不到就取父目录名
- `content` 中的 `[NL]` 表示原题目里的换行

## `[NL]` 是什么

为了让 Coze 一行只保留一道题，同时又不丢掉题目内部的原始换行，这个工具会把题内换行替换成 `[NL]`。

如果你不想保留这个标记，可以运行时改成别的内容，例如：

```powershell
python run_export.py "D:\path\to\pdf_folder" --output-dir "D:\path\to\output" --nl-token " "
```

这样题目内部换行会直接变成普通空格。

## 适用范围

- 适合：可直接提取文本的 PDF
- 不适合：纯扫描图片 PDF

## 常见问题

### 1. 报错 `No usable text was extracted`

通常说明这个 PDF 是扫描版，当前工具没有接 OCR。

### 2. 数学公式里有乱码

工具内置了一批常见 PDF 私有区符号映射，会自动把常见逻辑符号、集合符号恢复成正常字符。但如果某份 PDF 字体特别特殊，仍可能需要补映射表。

### 3. 有些题没有按题号切开

当前是规则切题，优先识别：

- `一、二、三`
- `1. 2. 3.`
- `1)`、`1）`

如果原始 PDF 抽出来的文本已经严重粘连，仍可能需要针对那一类试卷继续加规则。
